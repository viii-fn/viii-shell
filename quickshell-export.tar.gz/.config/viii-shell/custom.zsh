# --- CUSTOM COMMANDS ---

alias rebar='killall waybar; setsid waybar >/dev/null 2>&1 &!'
alias reshell='killall qs; setsid qs >/dev/null 2>&1 &!'
alias keybind='cat ~/.config/labwc/rc.xml'
alias clean='~/.local/bin/clean.sh'
alias note='micro ~/Documents/note.txt'

# Full-screen recording -> ~/Videos/Screenclips/clip_<timestamp>.mp4
# Stop with Ctrl+C
# Shared helper: records to .mkv, then converts to .mp4 when you stop (Ctrl+C)
# Extra args (like -g "$(slurp)" or --audio) are passed through to wf-recorder
_clip_record() {
  # Make the trap below local to this function so it doesn't leak into your shell
  setopt localoptions localtraps

  mkdir -p ~/Videos/Screenclips
  local base=~/Videos/Screenclips/clip_$(date +%Y-%m-%d_%H-%M-%S)

  # Without this, Ctrl+C would also kill THIS function and the conversion
  # below would never run. A non-empty trap handler runs in the shell only;
  # wf-recorder still gets a normal Ctrl+C and stops cleanly.
  trap ':' INT

  wf-recorder -x yuv420p -f "$base.mkv" "$@"

  echo "Converting to mp4..."
  # -nostdin: stops ffmpeg from reading your keyboard
  # &&: only delete the mkv if the conversion succeeded
  ffmpeg -nostdin -loglevel error -i "$base.mkv" \
    -c:v copy -c:a aac -movflags +faststart "$base.mp4" \
    && rm "$base.mkv" \
    && echo "Saved: $base.mp4" \
    || echo "Conversion failed, your recording is kept at: $base.mkv"
}

# Full screen
srec() {
  _clip_record "$@"
}

# Region: drag a box with the mouse first
srecm() {
  _clip_record -g "$(slurp)" "$@"
}

# --- END OF CUSTOM COMMANDS ---
