import QtQuick
import Quickshell
import Quickshell.Io
import Quickshell.Wayland

Scope {
    id: root

    function pickScreen() {
        for (let i = 0; i < Quickshell.screens.length; i++)
            if (Quickshell.screens[i].name.startsWith("eDP")) return Quickshell.screens[i]
        return Quickshell.screens[0]
    }

    IpcHandler {
        target: "clock"
        function toggle(): void { win.visible = !win.visible }
    }

    SystemClock {
        id: clock
        enabled: win.visible
        precision: SystemClock.Minutes
    }

    Process {
        id: loadPos
        command: ["sh", "-c", "cat ~/.local/state/quickshell-clock 2>/dev/null"]
        running: true
        stdout: StdioCollector {
            onStreamFinished: {
                const p = text.trim().split(" ")
                if (p.length === 2) {
                    face.x = parseInt(p[0])
                    face.y = parseInt(p[1])
                }
            }
        }
    }

    Process { id: savePos }

    component Mark: Text {
        color: "#e5e5e5"
        font.pixelSize: 15
    }

    PanelWindow {
        id: win
        screen: root.pickScreen()

        readonly property int hrs: clock.date.getHours()
        readonly property int mins: clock.date.getMinutes()

        function save() {
            savePos.command = [
                "sh", "-c",
                'mkdir -p ~/.local/state && echo "$0 $1" > ~/.local/state/quickshell-clock',
                String(Math.round(face.x)), String(Math.round(face.y))
            ]
            savePos.running = true
        }

        anchors { top: true; bottom: true; left: true; right: true }
        exclusionMode: ExclusionMode.Ignore
        WlrLayershell.layer: WlrLayer.Top
        WlrLayershell.namespace: "clock"
        color: "transparent"
        mask: Region { item: face }

        Rectangle {
            id: face
            x: 60
            y: 80
            width: 180
            height: 180
            radius: width / 2
            color: "#d9121212"
            border.width: 1
            border.color: "#888888"

            Mark { text: "12"; anchors.top: parent.top; anchors.topMargin: 12; anchors.horizontalCenter: parent.horizontalCenter }
            Mark { text: "6"; anchors.bottom: parent.bottom; anchors.bottomMargin: 12; anchors.horizontalCenter: parent.horizontalCenter }
            Mark { text: "3"; anchors.right: parent.right; anchors.rightMargin: 16; anchors.verticalCenter: parent.verticalCenter }
            Mark { text: "9"; anchors.left: parent.left; anchors.leftMargin: 16; anchors.verticalCenter: parent.verticalCenter }

            Rectangle {
                width: 4
                height: 38
                radius: 2
                color: "#e5e5e5"
                x: face.width / 2 - width / 2
                y: face.height / 2 - height
                transformOrigin: Item.Bottom
                rotation: (win.hrs % 12) * 30 + win.mins * 0.5
            }

            Rectangle {
                width: 3
                height: 56
                radius: 1.5
                color: "#98fb98"
                x: face.width / 2 - width / 2
                y: face.height / 2 - height
                transformOrigin: Item.Bottom
                rotation: win.mins * 6
            }

            Rectangle {
                width: 8
                height: 8
                radius: 4
                color: "#98fb98"
                anchors.centerIn: parent
            }

            MouseArea {
                anchors.fill: parent
                drag.target: face
                drag.minimumX: 0
                drag.maximumX: win.width - face.width
                drag.minimumY: 0
                drag.maximumY: win.height - face.height
                cursorShape: drag.active ? Qt.ClosedHandCursor : Qt.OpenHandCursor
                onReleased: win.save()
            }
        }
    }
}
